#define MyAppName "Videotoy"
#define MyAppPublisher "Patrick JAILLET"
#define MyAppURL "https://patrickjaillet.github.io/Videotoy"
#define MyAppExeName "Videotoy.exe"
#define MyAppExePath "..\src\Videotoy.App\bin\Release\net8.0-windows10.0.19041.0\" + MyAppExeName
#define MyAppIcon "..\src\Videotoy.App\Assets\Icons\app.ico"
#define MyInstallerIcon "installer.ico"

#if !FileExists(MyAppExePath)
  #error "Videotoy.exe is missing from the build output. Run the Release build (dotnet build Videotoy.sln -c Release) before packaging the installer."
#endif

#if !FileExists(MyAppIcon)
  #error "Application icon is missing (src\Videotoy.App\Assets\Icons\app.ico)."
#endif

#if !FileExists(MyInstallerIcon)
  #error "Installer icon is missing (installer\installer.ico)."
#endif

; Read straight from the compiled executable's version resource
; (set by Directory.Build.props / FileVersion), so the installer's
; version always matches the build it packages with no manual edit.
#define MyAppVersion GetVersionNumbersString(MyAppExePath)

[Setup]
AppId={{9F2E7C10-4A1B-4B7A-9D5A-000000000001}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
OutputDir=Output
OutputBaseFilename=Videotoy-Setup-{#MyAppVersion}
Compression=lzma2
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64
WizardStyle=modern
SetupIconFile={#MyInstallerIcon}
UninstallDisplayIcon={app}\{#MyAppExeName}
UninstallDisplayName={#MyAppName}
DisableProgramGroupPage=yes
DisableWelcomePage=no
ShowLanguageDialog=auto
MinVersion=10.0.22000

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"
Name: "french"; MessagesFile: "compiler:Languages\French.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "..\src\Videotoy.App\bin\Release\net8.0-windows10.0.19041.0\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs

#if !FileExists("..\src\Videotoy.App\bin\Release\net8.0-windows10.0.19041.0\tools\ffmpeg\ffmpeg.exe")
  #error "ffmpeg.exe is missing from the build output. Run the Release build with tools\ffmpeg\ffmpeg.exe present before packaging the installer."
#endif

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\{#MyAppExeName}"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"; IconFilename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#MyAppName}}"; Flags: nowait postinstall skipifsilent
