# Videotoy — ROADMAP

# Licence et Copyright
**Videotoy**
Copyright © 2026 Patrick JAILLET — Tous droits réservés
E-mail : sandefjord.development@proton.me
Site web : https://patrickjaillet.github.io/Videotoy

---

# Conventions de Développement Strictes

- [ ] Code source entièrement en anglais (noms de variables, fonctions, classes)
- [ ] Logiciel en Français et Anglais dans des fichiers `.json` (i18n)
- [ ] Aucun texte ou commentaire dans les fichiers de code
- [ ] Compatibilité avec Windows 11 uniquement
- [ ] Chaque fonctionnalité ajoutée doit être reflétée dans ce fichier ROADMAP.md
- [ ] Sérialisation automatique de la version du logiciel selon la norme stricte SemVer
- [ ] Ne pas mettre de nom de phase dans les fichiers ni sur GitHub, uniquement la version (vX.X.X)
- [ ] Chaque modification doit être automatiquement reflétée dans le fichier CHANGELOG.md
- [ ] Le fichier README.md doit être créé et mis à jour à chaque modification, incluant une capture d'écran du logiciel dans `docs/scs/screenshot.png`
- [ ] Création du fichier COMPILATION.md
- [ ] Création du site web de présentation utilisateur final sur GitHub Pages
- [ ] Ne pas ajouter ROADMAP.md, CLAUDE.md sur GitHub (`.gitignore`)
- [ ] Ne jamais intégrer Claude AI dans GitHub, les fichiers, ou la liste des contributeurs
- [ ] Création de tous les fichiers et documents requis pour le dépôt GitHub
- [ ] Intégrer copyright / e-mail / site web dans un onglet « À propos »
- [ ] Créer des icônes pour l'installateur Inno Setup 7 et pour le logiciel
- [ ] Licence MIT
- [ ] Aller droit au but, exhaustivité et rigueur technique professionnelle

---

# Vue d'ensemble technique

**Videotoy** est un logiciel Windows 11 en C# / F# / WPF permettant de charger un shader
Shadertoy (GLSL) et de le rendre en vidéo MP4, image par image, en s'appuyant sur un
pipeline de rendu déterministe (pas de dépendance au temps réel de la machine) et sur
un binaire `ffmpeg.exe` embarqué pour garantir un encodage fiable même sur une
configuration matérielle modeste.

**Stack :**
- C# — application host, ViewModels, orchestration, services I/O
- F# — moteur de transpilation/évaluation GLSL → HLSL et logique de rendu fonctionnelle pure
- WPF — interface utilisateur (MVVM strict) avec effets visuels (Fluent/Acrylic, animations)
- D3D11 (via SharpDX/Vortice.Windows ou équivalent) pour le rendu du shader hors-écran
- FFmpeg (binaire embarqué, `ffmpeg.exe` livré dans le package, aucune installation requise)

---

## [x] Phase v0.1.0 — Socle du projet

- [x] Création de la solution `.sln` avec projets séparés : `Videotoy.App` (WPF, C#), `Videotoy.Core` (F#), `Videotoy.Rendering` (C#/F#), `Videotoy.Ffmpeg` (C#)
- [x] Configuration `.editorconfig`, `Directory.Build.props`, nullable enabled, LangVersion latest
- [x] Mise en place du versioning SemVer automatique (constante `Version.fs` + `Directory.Build.props`, base pour `GitVersion` ultérieur)
- [x] Structure des dossiers : `/src`, `/assets`, `/tools/ffmpeg`, `/docs`, `/installer`
- [x] `.gitignore` incluant `ROADMAP.md`, `CLAUDE.md`, `bin/`, `obj/`, `*.user`
- [x] Fichier `LICENSE` (MIT)
- [x] Squelette `README.md`
- [x] Squelette `CHANGELOG.md` (format Keep a Changelog + SemVer)
- [x] Squelette `COMPILATION.md`
- [x] Pipeline CI GitHub Actions (build + tests, Windows only)

## [x] Phase v0.2.0 — Fenêtre principale & shell WPF

- [x] Fenêtre principale sans chrome natif (custom title bar) avec effet Mica Windows 11 (via `DwmSetWindowAttribute`)
- [x] Architecture MVVM (CommunityToolkit.Mvvm), injection de dépendances (Microsoft.Extensions.DependencyInjection) pour les services partagés
- [x] Viewport de prévisualisation fixe **800x450**, ancré et non redimensionnable, avec cadre stylisé
- [x] Barre de menu supérieure (Fichier, Édition, Rendu, Aide) avec icônes vectorielles
- [x] Barre de statut inférieure (FPS courant, frame en cours, statut encodage)
- [x] Panneau latéral rétractable pour les paramètres de rendu (animation de largeur via `Storyboard`)
- [x] Système de thème **clair unique** (pas de mode sombre, pas de bascule de thème)
- [x] Animations d'interface (ouverture/fermeture du panneau, hover sur boutons) via Storyboards et styles de contrôle
- [x] Effets visuels : glow sur le bouton principal au survol, ombres portées sur les cartes, coins arrondis Windows 11
- [x] Fenêtre « À propos » : nom du logiciel, version SemVer, copyright, e-mail, site web

## [x] Phase v0.3.0 — Chargement des shaders

- [x] Chargement de fichier shader via menu « Fichier > Ouvrir »
- [x] Support du Drag & Drop de fichiers `.glsl` / `.frag` / `.shadertoy` / `.json` (export Shadertoy) sur le viewport
- [x] Parsing du format d'export Shadertoy (JSON avec multi-passes, buffers A/B/C/D, Common)
- [x] Détection et affichage des erreurs de compilation shader dans un panneau dédié (avec numéro de ligne)
- [x] Gestion des uniforms standards Shadertoy : `iResolution`, `iTime`, `iTimeDelta`, `iFrame`, `iMouse`, `iDate`, `iChannel0-3`, `iSampleRate`
- [x] Support des textures d'entrée (`iChannel`) : image statique, chargement additionnel par l'utilisateur
- [x] Support des sources audio en entrée (`iChannel` de type `Audio`/`Music`) : chargement de fichier audio (WAV/MP3/OGG) comme source du spectre/waveform passé au shader
- [x] Décodage du fichier audio source et génération de la texture spectre/waveform 512x2 (format Shadertoy) pour chaque frame de rendu, de façon déterministe (basée sur `iTime` de la frame, pas sur une lecture temps réel)
- [x] Liste des shaders récemment ouverts (menu + persistance JSON)

## [] Phase v0.4.0 — Moteur de rendu déterministe

- [x] Traduction/compilation GLSL Shadertoy → HLSL (via bibliothèque de transpilation ou pipeline ANGLE/glslang + SPIRV-Cross)
- [x] Contexte de rendu D3D11 hors-écran (render target 800x450 pour la prévisualisation, résolution paramétrable pour l'export)
- [x] Horloge de rendu **déterministe** : le temps `iTime` est calculé à partir du numéro de frame et du FPS cible, indépendamment de la vitesse de la machine
- [x] Rendu image par image en mémoire (pas de rendu temps réel pendant l'export)
- [x] Support multi-passes (Buffer A/B/C/D + Image) avec ping-pong de render targets
- [x] Gestion de la boucle de prévisualisation dans le viewport (lecture temps réel, play/pause/scrub)
- [x] Timeline de prévisualisation avec curseur de progression

## [x] Phase v0.5.0 — Pipeline d'export vidéo (FFmpeg)

- [x] Embarquement du binaire `ffmpeg.exe` dans `/tools/ffmpeg` (inclus dans le build et l'installateur)
- [x] Vérification d'intégrité du binaire embarqué au démarrage (hash SHA-256)
- [x] Service `FfmpegService` : lancement du process, pipe stdin binaire (frames brutes RGB/BGRA) → FFmpeg, sans écriture disque intermédiaire
- [x] Génération image par image : rendu GPU → lecture back-buffer → conversion pixel format → écriture dans le pipe FFmpeg
- [x] Paramètres d'export : résolution de sortie, FPS cible, durée, codec (H.264/H.265), bitrate/CRF, container MP4
- [x] Barre de progression d'export avec estimation du temps restant, frame courante/totale
- [x] Annulation propre de l'export en cours (kill process FFmpeg + nettoyage)
- [x] Gestion des erreurs FFmpeg (parsing stderr, remontée UI claire)
- [x] Mode « petite config » : rendu séquentiel garanti sans frame perdue, throttling CPU/GPU si nécessaire, pas de dépendance à la fluidité temps réel
- [x] Enregistrement de la piste audio dans la vidéo exportée lorsque le shader utilise un `iChannel` audio : le fichier audio source (ou sa portion couverte par la durée d'export) est muxé par FFmpeg avec la vidéo générée, en une seule passe d'encodage
- [x] Alignement strict de la piste audio sur la timeline de rendu déterministe (même origine `t = 0`, même durée totale que la vidéo, y compris en mode boucle parfaite pour un raccord audio sans coupure)
- [x] Option d'export « Vidéo sans son » / « Vidéo avec son » lorsque le shader chargé possède un `iChannel` audio

## [x] Phase v0.6.0 — Panneau de paramètres de rendu

- [x] UI de configuration d'export : résolution (presets + custom), FPS (24/25/30/60/custom), durée en secondes/frames
- [x] Presets de format d'aspect supplémentaires dans le sélecteur de résolution : « Écran 4:3 », « Écran 16:9 », « Smartphone 9:16 » (portrait), chacun avec une ou plusieurs résolutions concrètes proposées (ex. 1440x1080 pour 4:3, 1920x1080 pour 16:9, 1080x1920 pour 9:16), au même niveau que les presets existants (Preview/SD/HD/Full HD/4K/Custom)
- [x] Prévisualisation du nombre total de frames et poids estimé du fichier
- [x] Sélecteur de dossier de sortie + nom de fichier
- [x] Sauvegarde/chargement de presets d'export (JSON)
- [x] Aperçu en direct des uniforms custom (si le shader en expose) avec sliders générés dynamiquement
- [x] Mode « Durée manuelle » : l'utilisateur saisit une durée fixe en secondes/frames (comportement standard)
- [x] Mode « Boucle parfaite (Seamless Loop) » : l'utilisateur saisit une période de boucle en secondes (ou en frames), et le rendu s'arrête exactement sur la dernière frame précédant le redémarrage du cycle, garantissant un raccord `dernière frame → première frame` sans saut ni répétition de frame
- [x] Calcul automatique du nombre exact de frames à exporter en mode boucle : `frameCount = round(loopDurationSeconds * fps)`, avec avertissement UI si `loopDurationSeconds * fps` n'est pas un nombre entier (risque de micro-saut au raccord, avec option d'arrondi assisté)
- [x] Option « Frame de fin exclusive » : exclut automatiquement la frame à `t = loopDuration` (identique à `t = 0`) pour éviter une image dupliquée lors de la lecture en boucle
- [x] Prévisualisation dédiée du raccord de boucle : affichage côte à côte de la première et de la dernière frame générées, pour validation visuelle avant export
- [x] Détection assistée (optionnelle) de la période de boucle native du shader, lorsque celui-ci utilise des fonctions périodiques simples sur `iTime` (heuristique, non garantie pour les shaders complexes) — proposée comme valeur par défaut éditable, jamais imposée
- [x] Persistance du dernier mode de durée choisi (manuel/boucle) et de la dernière période de boucle utilisée par shader

## [x] Phase v0.7.0 — Internationalisation (i18n)

- [x] Fichiers `fr.json` et `en.json` pour toutes les chaînes de l'interface
- [x] Service de localisation avec changement de langue à chaud (sans redémarrage)
- [x] Détection de la langue système au premier lancement
- [x] Sélecteur de langue dans les paramètres/À propos

## [x] Phase v0.8.0 — Polish UI/FX

- [x] Animations de chargement (splash screen animé au démarrage)
- [x] Effets de transition entre les modes « Édition » et « Export »
- [x] Indicateurs visuels animés pendant le rendu (pulse, progress ring)
- [x] Notifications toast non intrusives (succès export, erreurs)
- [x] Personnalisation de la scrollbar, tooltips stylisés, curseurs contextuels
- [x] Icône du logiciel (multi-résolutions .ico) et icône de l'installateur

## [] Phase v0.9.0 — Documentation & dépôt GitHub

- [x] `README.md` complet (présentation, fonctionnalités, capture d'écran `docs/scs/screenshot.png`, installation, usage)
- [x] `COMPILATION.md` (prérequis, étapes de build, génération de l'installateur)
- [x] `CHANGELOG.md` tenu à jour à chaque version
- [ ] Site de présentation GitHub Pages (page unique, vitrine, lien de téléchargement, captures)
- [x] Configuration `.gitignore` finale (exclusion `ROADMAP.md`, `CLAUDE.md`)
- [x] Vérification qu'aucune mention de Claude/IA n'apparaît dans les fichiers, commits ou contributeurs

## [] Phase v1.0.0 — Installateur & release

- [x] Script Inno Setup 7 avec icônes personnalisées (installateur + raccourcis)
- [ ] Embarquement de `ffmpeg.exe` dans le package d'installation
- [ ] Signature/vérification de version affichée dans l'installateur (SemVer)
- [ ] Tests d'installation/désinstallation propre sur Windows 11 vierge
- [ ] Publication de la release GitHub (tag `vX.X.X`, binaire, notes de version issues du CHANGELOG)
- [ ] Mise à jour finale du site GitHub Pages avec le lien de téléchargement de la release

---

## Post v1.0.0 — Pistes d'évolution (non planifiées)

- [ ] Export en formats additionnels (WebM, ProRes)
- [ ] Support de textures vidéo en entrée (`iChannel` vidéo)
- [ ] File d'attente de rendu (batch de plusieurs shaders)
- [ ] Undo/redo sur les paramètres de rendu
- [ ] Export direct en GIF/WebP animé en boucle parfaite (réutilisation du calcul de période de boucle)
